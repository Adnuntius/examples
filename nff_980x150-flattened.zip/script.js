var jsonData = '{"width":980,"height":150,"states":[{"id":"s1","name":"organized","text":"","nodes":[{"id":"n1","size":114,"x":438,"y":28,"type":"jorunn","visibility":"full"},{"id":"n2","size":91,"x":600.5,"y":120.5,"type":"helge","visibility":"full"},{"id":"n3","size":86,"x":730,"y":25,"type":"lise","visibility":"full"},{"id":"n7","size":45,"x":507.5,"y":109.5,"type":"task","visibility":"full"},{"id":"n4","size":64,"x":353,"y":109,"type":"robot","visibility":"full"},{"id":"n5","size":61,"x":599.5,"y":27.5,"type":"calendar","visibility":"full"},{"id":"n14","size":43,"x":803.5,"y":67.5,"type":"computer","visibility":"full"},{"id":"n9","size":42,"x":279,"y":109,"type":"corona","visibility":"full"},{"id":"n30","size":42,"x":408,"y":175,"type":"issue","visibility":"full"},{"id":"n8","size":42,"x":312,"y":53,"type":"legal","visibility":"full"},{"id":"n6","size":50,"x":732,"y":119,"type":"meeting","visibility":"full"},{"id":"n13","size":54,"x":888,"y":41,"type":"cloud","visibility":"full"},{"id":"n12","size":44,"x":854,"y":98,"type":"personalDataItem","visibility":"full"},{"id":"n28","size":47,"x":447.5,"y":222.5,"type":"riskAssessment","visibility":"hidden"},{"id":"n29","size":30,"x":493,"y":242,"type":"qualityReview","visibility":"hidden"}],"edges":[{"a":"n4","b":"n8"},{"a":"n4","b":"n7"},{"a":"n5","b":"n7"},{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n2","b":"n6"},{"a":"n3","b":"n5"},{"a":"n3","b":"n14"},{"a":"n12","b":"n14"},{"a":"n12","b":"n13"},{"a":"n3","b":"n6"},{"a":"n4","b":"n9"},{"a":"n28","b":"n29"},{"a":"n4","b":"n30"},{"a":"n28","b":"n30"}]},{"id":"s11","name":"complience","text":"","nodes":[{"id":"n1","size":96,"x":615,"y":31,"type":"jorunn","visibility":"full"},{"id":"n2","size":92,"x":749,"y":135,"type":"helge","visibility":"full"},{"id":"n3","size":109,"x":870.5,"y":76.5,"type":"lise","visibility":"full"},{"id":"n7","size":45,"x":663.5,"y":108.5,"type":"task","visibility":"full"},{"id":"n4","size":64,"x":557,"y":108,"type":"robot","visibility":"full"},{"id":"n30","size":57,"x":443.5,"y":192.5,"type":"issue","visibility":"full"},{"id":"n6","size":50,"x":872,"y":192,"type":"meeting","visibility":"full"},{"id":"n5","size":46,"x":745,"y":31,"type":"calendar","visibility":"full"},{"id":"n14","size":43,"x":1019.5,"y":71.5,"type":"computer","visibility":"full"},{"id":"n9","size":26,"x":508,"y":115,"type":"corona","visibility":"hidden"},{"id":"n8","size":104,"x":461,"y":62,"type":"legal","visibility":"full"},{"id":"n13","size":54,"x":1077,"y":-44,"type":"cloud","visibility":"full"},{"id":"n12","size":44,"x":1075,"y":70,"type":"personalDataItem","visibility":"full"},{"id":"n11","size":23,"x":538.5,"y":37.5,"type":"riskAssessment","visibility":"hidden"},{"id":"n10","size":20,"x":583,"y":107,"type":"task","visibility":"hidden"}],"edges":[{"a":"n4","b":"n8"},{"a":"n4","b":"n9"},{"a":"n4","b":"n7"},{"a":"n5","b":"n7"},{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n3","b":"n5"},{"a":"n2","b":"n6"},{"a":"n3","b":"n6"},{"a":"n3","b":"n14"},{"a":"n12","b":"n14"},{"a":"n12","b":"n13"},{"a":"n4","b":"n11"},{"a":"n4","b":"n30"}]},{"id":"s2","name":"infectioncontrol","text":"","nodes":[{"id":"n1","size":131,"x":882.5,"y":75.5,"type":"jorunn","visibility":"full"},{"id":"n2","size":92,"x":762,"y":216,"type":"helge","visibility":"full"},{"id":"n3","size":72,"x":1036,"y":79,"type":"lise","visibility":"hidden"},{"id":"n7","size":54,"x":647,"y":111,"type":"task","visibility":"full"},{"id":"n4","size":109,"x":527.5,"y":75.5,"type":"robot","visibility":"full"},{"id":"n5","size":85,"x":755.5,"y":75.5,"type":"calendar","visibility":"full"},{"id":"n14","size":43,"x":1031.5,"y":8.5,"type":"computer","visibility":"hidden"},{"id":"n9","size":77,"x":362.5,"y":76.5,"type":"corona","visibility":"full"},{"id":"n8","size":24,"x":452,"y":18,"type":"legal","visibility":"hidden"},{"id":"n11","size":54,"x":647,"y":37,"type":"riskAssessment","visibility":"full"},{"id":"n17","size":77,"x":422.5,"y":-76.5,"type":"personalDataItem","visibility":"hidden"},{"id":"n16","size":46,"x":326,"y":-112,"type":"cloud","visibility":"hidden"},{"id":"n15","size":55,"x":536.5,"y":-75.5,"type":"computer","visibility":"hidden"},{"id":"n18","size":40,"x":575,"y":-144,"type":"personalDataItem","visibility":"hidden"},{"id":"n30","size":57,"x":399.5,"y":183.5,"type":"issue","visibility":"full"}],"edges":[{"a":"n4","b":"n8"},{"a":"n4","b":"n9"},{"a":"n4","b":"n7"},{"a":"n5","b":"n7"},{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n3","b":"n5"},{"a":"n4","b":"n11"},{"a":"n3","b":"n14"},{"a":"n16","b":"n17"},{"a":"n15","b":"n17"},{"a":"n2","b":"n15"},{"a":"n15","b":"n18"},{"a":"n4","b":"n30"}]},{"id":"s3","name":"privacy","text":"","nodes":[{"id":"n1","size":42,"x":904,"y":195,"type":"jorunn","visibility":"hidden"},{"id":"n2","size":124,"x":655,"y":74,"type":"helge","visibility":"full"},{"id":"n3","size":124,"x":899,"y":74,"type":"lise","visibility":"full"},{"id":"n7","size":30,"x":662,"y":222,"type":"task","visibility":"hidden"},{"id":"n4","size":59,"x":533.5,"y":195.5,"type":"robot","visibility":"hidden"},{"id":"n5","size":37,"x":789.5,"y":195.5,"type":"calendar","visibility":"full"},{"id":"n14","size":66,"x":776,"y":74,"type":"computer","visibility":"full"},{"id":"n9","size":61,"x":430.5,"y":194.5,"type":"corona","visibility":"hidden"},{"id":"n11","size":42,"x":661,"y":175,"type":"riskAssessment","visibility":"hidden"},{"id":"n17","size":124,"x":418,"y":74,"type":"personalDataItem","visibility":"full"},{"id":"n16","size":70,"x":303,"y":46,"type":"cloud","visibility":"full"},{"id":"n15","size":66,"x":539,"y":75,"type":"computer","visibility":"full"},{"id":"n18","size":40,"x":537,"y":-40,"type":"personalDataItem","visibility":"full"},{"id":"n30","size":57,"x":475.5,"y":265.5,"type":"issue","visibility":"hidden"}],"edges":[{"a":"n4","b":"n9"},{"a":"n4","b":"n7"},{"a":"n5","b":"n7"},{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n3","b":"n5"},{"a":"n4","b":"n11"},{"a":"n3","b":"n14"},{"a":"n16","b":"n17"},{"a":"n15","b":"n17"},{"a":"n2","b":"n15"},{"a":"n15","b":"n18"},{"a":"n4","b":"n30"}]},{"id":"s4","name":"calendar","text":"","nodes":[{"id":"n1","size":113,"x":696.5,"y":119.5,"type":"jorunn","visibility":"full"},{"id":"n2","size":131,"x":365.5,"y":73.5,"type":"helge","visibility":"full"},{"id":"n3","size":134,"x":807,"y":26,"type":"lise","visibility":"full"},{"id":"n7","size":30,"x":528,"y":224,"type":"task","visibility":"full"},{"id":"n4","size":59,"x":585.5,"y":331.5,"type":"robot","visibility":"hidden"},{"id":"n5","size":90,"x":527,"y":74,"type":"calendar","visibility":"full"},{"id":"n14","size":66,"x":918,"y":94,"type":"computer","visibility":"full"},{"id":"n9","size":61,"x":546.5,"y":403.5,"type":"corona","visibility":"hidden"},{"id":"n11","size":42,"x":512,"y":288,"type":"riskAssessment","visibility":"hidden"},{"id":"n17","size":55,"x":307.5,"y":271.5,"type":"personalDataItem","visibility":"hidden"},{"id":"n16","size":42,"x":246,"y":250,"type":"cloud","visibility":"hidden"},{"id":"n15","size":42,"x":340,"y":207,"type":"computer","visibility":"hidden"},{"id":"n18","size":25,"x":279.5,"y":194.5,"type":"personalDataItem","visibility":"hidden"},{"id":"n19","size":20,"x":312,"y":73,"type":"function","visibility":"hidden"},{"id":"n20","size":20,"x":648,"y":138,"type":"function","visibility":"hidden"},{"id":"n21","size":20,"x":753,"y":30,"type":"function","visibility":"hidden"}],"edges":[{"a":"n4","b":"n9"},{"a":"n4","b":"n7"},{"a":"n5","b":"n7"},{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n3","b":"n5"},{"a":"n4","b":"n11"},{"a":"n3","b":"n14"},{"a":"n16","b":"n17"},{"a":"n15","b":"n17"},{"a":"n2","b":"n15"},{"a":"n15","b":"n18"},{"a":"n2","b":"n19"},{"a":"n1","b":"n20"},{"a":"n3","b":"n21"}]},{"id":"s5","name":"responsibility","text":"","nodes":[{"id":"n1","size":120,"x":664,"y":75,"type":"jorunn","visibility":"full"},{"id":"n2","size":120,"x":452,"y":75,"type":"helge","visibility":"full"},{"id":"n3","size":120,"x":878,"y":75,"type":"lise","visibility":"full"},{"id":"n7","size":30,"x":526,"y":310,"type":"task","visibility":"hidden"},{"id":"n19","size":50,"x":348,"y":75,"type":"function","visibility":"full"},{"id":"n20","size":50,"x":560,"y":75,"type":"function","visibility":"full"},{"id":"n21","size":50,"x":776,"y":75,"type":"function","visibility":"full"},{"id":"n31","size":98,"x":601,"y":-68,"type":"bemanning","visibility":"hidden"},{"id":"n14","size":39,"x":1032.5,"y":66.5,"type":"computer","visibility":"hidden"},{"id":"n5","size":46,"x":524,"y":220,"type":"calendar","visibility":"hidden"}],"edges":[{"a":"n5","b":"n7"},{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n3","b":"n5"},{"a":"n3","b":"n14"},{"a":"n3","b":"n21"},{"a":"n1","b":"n20"},{"a":"n2","b":"n19"},{"a":"n2","b":"n31"},{"a":"n1","b":"n31"},{"a":"n3","b":"n31"}]},{"id":"s6","name":"staffing","text":"","nodes":[{"id":"n1","size":98,"x":810,"y":27,"type":"jorunn","visibility":"full"},{"id":"n2","size":107,"x":436.5,"y":78.5,"type":"helge","visibility":"full"},{"id":"n3","size":120,"x":900,"y":120,"type":"lise","visibility":"full"},{"id":"n7","size":22,"x":475,"y":-94,"type":"task","visibility":"full"},{"id":"n26","size":46,"x":746,"y":-70,"type":"asset","visibility":"hidden"},{"id":"n25","size":46,"x":692,"y":-71,"type":"asset","visibility":"hidden"},{"id":"n27","size":22,"x":720,"y":-36,"type":"task","visibility":"hidden"},{"id":"n24","size":46,"x":632,"y":-71,"type":"asset","visibility":"hidden"},{"id":"n23","size":46,"x":574,"y":-71,"type":"asset","visibility":"hidden"},{"id":"n19","size":50,"x":436,"y":-33,"type":"function","visibility":"full"},{"id":"n31","size":203,"x":630.5,"y":85.5,"type":"bemanning","visibility":"full"},{"id":"n20","size":24,"x":773,"y":33,"type":"function","visibility":"hidden"},{"id":"n21","size":30,"x":861,"y":116,"type":"function","visibility":"hidden"},{"id":"n22","size":20,"x":604,"y":-37,"type":"task","visibility":"hidden"}],"edges":[{"a":"n3","b":"n21"},{"a":"n1","b":"n20"},{"a":"n2","b":"n19"},{"a":"n25","b":"n27"},{"a":"n26","b":"n27"},{"a":"n3","b":"n27"},{"a":"n1","b":"n26"},{"a":"n3","b":"n31"},{"a":"n1","b":"n31"},{"a":"n2","b":"n31"},{"a":"n22","b":"n23"},{"a":"n22","b":"n24"},{"a":"n2","b":"n22"}]},{"id":"s7","name":"assets","text":"","nodes":[{"id":"n1","size":121,"x":899.5,"y":74.5,"type":"jorunn","visibility":"full"},{"id":"n2","size":72,"x":537,"y":100,"type":"helge","visibility":"full"},{"id":"n3","size":72,"x":693,"y":102,"type":"lise","visibility":"full"},{"id":"n7","size":36,"x":587,"y":-81,"type":"task","visibility":"full"},{"id":"n4","size":49,"x":503.5,"y":-113.5,"type":"robot","visibility":"full"},{"id":"n30","size":32,"x":467,"y":-81,"type":"issue","visibility":"full"},{"id":"n28","size":28,"x":447,"y":-48,"type":"riskAssessment","visibility":"full"},{"id":"n26","size":50,"x":798,"y":35,"type":"asset","visibility":"full"},{"id":"n25","size":50,"x":733,"y":35,"type":"asset","visibility":"full"},{"id":"n27","size":36,"x":765,"y":101,"type":"task","visibility":"full"},{"id":"n24","size":50,"x":643,"y":35,"type":"asset","visibility":"full"},{"id":"n23","size":50,"x":580,"y":35,"type":"asset","visibility":"full"},{"id":"n19","size":50,"x":520,"y":-39,"type":"function","visibility":"hidden"},{"id":"n31","size":102,"x":575,"y":232,"type":"bemanning","visibility":"hidden"},{"id":"n22","size":36,"x":610,"y":101,"type":"task","visibility":"full"},{"id":"n29","size":24,"x":445,"y":-15,"type":"qualityReview","visibility":"full"}],"edges":[{"a":"n2","b":"n19"},{"a":"n25","b":"n27"},{"a":"n26","b":"n27"},{"a":"n3","b":"n27"},{"a":"n1","b":"n26"},{"a":"n2","b":"n31"},{"a":"n3","b":"n31"},{"a":"n1","b":"n31"},{"a":"n22","b":"n23"},{"a":"n22","b":"n24"},{"a":"n2","b":"n22"},{"a":"n4","b":"n7"},{"a":"n4","b":"n30"},{"a":"n28","b":"n30"},{"a":"n28","b":"n29"}]},{"id":"s9","name":"improvement","text":"","nodes":[{"id":"n1","size":43,"x":602.5,"y":-66.5,"type":"jorunn","visibility":"hidden"},{"id":"n2","size":45,"x":579.5,"y":206.5,"type":"helge","visibility":"hidden"},{"id":"n3","size":50,"x":736,"y":-62,"type":"lise","visibility":"hidden"},{"id":"n7","size":34,"x":544,"y":-27,"type":"task","visibility":"full"},{"id":"n4","size":64,"x":457,"y":77,"type":"robot","visibility":"full"},{"id":"n28","size":106,"x":705,"y":75,"type":"riskAssessment","visibility":"full"},{"id":"n29","size":106,"x":842,"y":75,"type":"qualityReview","visibility":"full"},{"id":"n30","size":106,"x":568,"y":75,"type":"issue","visibility":"full"},{"id":"n22","size":25,"x":622.5,"y":206.5,"type":"task","visibility":"hidden"},{"id":"n23","size":21,"x":614.5,"y":181.5,"type":"asset","visibility":"hidden"},{"id":"n24","size":21,"x":632.5,"y":181.5,"type":"asset","visibility":"hidden"},{"id":"n27","size":25,"x":778.5,"y":-81.5,"type":"task","visibility":"hidden"},{"id":"n25","size":24,"x":765,"y":-107,"type":"asset","visibility":"hidden"},{"id":"n6","size":62,"x":721,"y":182,"type":"meeting","visibility":"hidden"},{"id":"n5","size":41,"x":677.5,"y":-36.5,"type":"calendar","visibility":"hidden"},{"id":"n14","size":34,"x":790,"y":-39,"type":"computer","visibility":"hidden"},{"id":"n9","size":16,"x":419,"y":78,"type":"corona","visibility":"hidden"},{"id":"n8","size":17,"x":430.5,"y":53.5,"type":"legal","visibility":"hidden"},{"id":"n13","size":26,"x":853,"y":-69,"type":"cloud","visibility":"hidden"},{"id":"n12","size":27,"x":831.5,"y":-39.5,"type":"personalDataItem","visibility":"hidden"},{"id":"n26","size":24,"x":798,"y":-108,"type":"asset","visibility":"hidden"}],"edges":[{"a":"n2","b":"n6"},{"a":"n3","b":"n6"},{"a":"n1","b":"n6"},{"a":"n28","b":"n29"},{"a":"n1","b":"n5"},{"a":"n3","b":"n5"},{"a":"n2","b":"n5"},{"a":"n5","b":"n7"},{"a":"n3","b":"n14"},{"a":"n12","b":"n14"},{"a":"n12","b":"n13"},{"a":"n4","b":"n8"},{"a":"n4","b":"n9"},{"a":"n4","b":"n30"},{"a":"n28","b":"n30"},{"a":"n4","b":"n7"},{"a":"n2","b":"n22"},{"a":"n22","b":"n23"},{"a":"n22","b":"n24"},{"a":"n3","b":"n27"},{"a":"n25","b":"n27"},{"a":"n26","b":"n27"}]}]}';
var states = [];
var stateMap = {};
var stateIndex = 0;
var prevStateIndex = -1;
var artboardWidth = 980;
var artboardHeight = 150;
var textTopBefore = 150;
var textTopDuring = 22;
var textTopAfter = -30;
var edgeWidth = 3;
var slideDuration = 3000;
var transitionDuration = .5;
var keySplines = '.42 0 .58 1';

function getEdgeCoordinates(ax, ay, ar, bx, by, br) {
	var w = bx - ax;
	var h = by - ay;
	var length = Math.sqrt(Math.pow(w, 2) + Math.pow(h, 2));
	var aFactor = ar / length;
	var bFactor = br / length;
	ax = ax + w * aFactor;
	bx = bx - w * bFactor;
	ay = ay + h * aFactor;
	by = by - h * bFactor;
	return {ax: ax, ay: ay, bx: bx, by: by}
}

function createStateMap(states) {
	states.forEach(function(state) {
		stateMap[state.id] = {
			nodes:{}, 
			edges:{}
		};
		state.nodes.forEach(function(node) {
			stateMap[state.id].nodes[node.id] = node;
		});
		state.edges.forEach(function(edge) {
			edge.id = edge.a + edge.b;
			var nodeA = stateMap[state.id].nodes[edge.a];
			var nodeB = stateMap[state.id].nodes[edge.b];
			if (nodeA && nodeB) {
				var edgeCoordinates = getEdgeCoordinates(nodeA.x, nodeA.y, nodeA.size / 2, nodeB.x, nodeB.y, nodeB.size / 2);
				edge.ax = edgeCoordinates.ax;
				edge.ay = edgeCoordinates.ay;
				edge.bx = edgeCoordinates.bx;
				edge.by = edgeCoordinates.by;
				edge.opacity = 1;
				if (nodeA.visibility === 'damped' || nodeB.visibility === 'damped') {
					edge.opacity = 0.3;
				}
				if (nodeA.visibility === 'hidden' || nodeB.visibility === 'hidden') {
					edge.opacity = 0;
				}
				stateMap[state.id].edges[edge.id] = edge;
			}
		});
	});
}

function addEdgeData(states, stateMap) {
	states.forEach(function(state) {
		state.edges.forEach(function(edge) {
			edge = stateMap[state.id].edges[edge.a + edge.b];
		});
	});
}

function insertEdge(edge) {
	var line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
	line.setAttribute('id', edge.id);
	line.setAttribute('x1', edge.ax);
	line.setAttribute('y1', edge.ay);
	line.setAttribute('x2', edge.bx);
	line.setAttribute('y2', edge.by);
	line.setAttribute('y2', edge.by);
	line.setAttribute('stroke', 'white')
	line.setAttribute('stroke-width', edgeWidth);
	line.setAttribute('stroke-opacity', 0);
	document.getElementById('edges').appendChild(line);
}

function animateEdgeProperty(edgeId, attributeName, from, to) {
	if(!document.getElementById('animate-' + stateIndex + '-' + edgeId + '-' + attributeName)) {
		var animate = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
		animate.setAttribute('id', 'animate-' + stateIndex + '-' + edgeId + '-' + attributeName);
		animate.setAttribute('attributeName', attributeName);
		animate.setAttribute('from', from);
		animate.setAttribute('to', to);
		animate.setAttribute('dur', transitionDuration + 's');
		animate.setAttribute('calcMode', 'spline');
		animate.setAttribute('keyTimes', '0; 1');
		animate.setAttribute('keySplines', keySplines);
		animate.setAttribute('fill', 'freeze');
		document.getElementById(edgeId).appendChild(animate);
	}
	document.getElementById('animate-' + stateIndex + '-' + edgeId + '-' + attributeName).beginElement();
	setTimeout(function() {
		var edge = document.getElementById(edgeId);
	}, transitionDuration * 1000);
}

function removeEdge(edgeId) {
	var animate = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
	animate.setAttribute('id', 'animate-' + edgeId);
	animate.setAttribute('attributeName', 'stroke-opacity');
	animate.setAttribute('to', 0);
	animate.setAttribute('dur', transitionDuration + 's');
	animate.setAttribute('calcMode', 'spline');
	animate.setAttribute('keyTimes', '0; 1');
	animate.setAttribute('keySplines', keySplines);
	animate.setAttribute('fill', 'freeze');
	document.getElementById(edgeId).appendChild(animate);
	document.getElementById('animate-' + edgeId).beginElement();
	setTimeout(function() {
		if (document.getElementById(edgeId)) {
			document.getElementById(edgeId).remove();
		}
	}, transitionDuration * 1000 + 100);
}

function run() {
	if (stateIndex > states.length - 1) {
		stateIndex = 0;
	}
	var state = states[stateIndex];
	var svg = document.getElementById('edges');
	var existingEdges = svg.querySelectorAll('line');
	var existingEdgeIds = [];
	existingEdges.forEach(function(edge) {
		existingEdgeIds.push(edge.id);
		if (stateMap[state.id].edges[edge.id]) {
			var prevStateEdge = stateMap[states[prevStateIndex].id].edges[edge.id];
			if (prevStateEdge) {
				var currentStateEdge = stateMap[states[stateIndex].id].edges[edge.id];
				animateEdgeProperty(edge.id, 'x1', prevStateEdge.ax, currentStateEdge.ax);
				animateEdgeProperty(edge.id, 'x2', prevStateEdge.bx, currentStateEdge.bx);
				animateEdgeProperty(edge.id, 'y1', prevStateEdge.ay, currentStateEdge.ay);
				animateEdgeProperty(edge.id, 'y2', prevStateEdge.by, currentStateEdge.by);
				animateEdgeProperty(edge.id, 'stroke-opacity', prevStateEdge.opacity, currentStateEdge.opacity);
			} else {
				removeEdge(edge.id);
			}
		} else {
			removeEdge(edge.id);
		}
	});
	state.edges.forEach(function(edge) {
		if (existingEdgeIds.indexOf(edge.id) < 0) {
			insertEdge(edge);
			animateEdgeProperty(edge.id, 'stroke-opacity', 0, edge.opacity);
		}
	});
	state.nodes.forEach(function(node) {
		var opacity = 0;
		if (node.visibility === 'full') {
			opacity = 1;
		}
		var elem = document.getElementById(node.id);
		var shadowDist = (node.size / 60) * (node.size / 60);
		var shadowBlur = (node.size / 40) * (node.size / 80) + 4;
		var shadowSpread = node.size / 100;
		if (elem) {
			elem.style.left = node.x - node.size / 2 + 'px';
			elem.style.top = node.y - node.size / 2 + 'px';
			elem.style.width = node.size + 'px';
			elem.style.height = node.size + 'px';
			elem.style.opacity = opacity;
			elem.style.boxShadow = 'rgba(0, 0, 0, 0.3) ' + shadowDist + 'px ' + shadowDist + 'px ' + shadowBlur + 'px ' + shadowSpread + 'px';
		} else {
			elem = document.createElement('div');
			elem.id = node.id;
			elem.className = 'node ' + node.type;
			elem.style.left = node.x - node.size / 2 + 'px';
			elem.style.top = node.y - node.size / 2 + 'px';
			elem.style.width = node.size + 'px';
			elem.style.height = node.size + 'px';
			elem.style.opacity = 0;
			elem.style.boxShadow = 'rgba(0, 0, 0, 0.3) ' + shadowDist + 'px ' + shadowDist + 'px ' + shadowBlur + 'px ' + shadowSpread + 'px';
			document.getElementById('nodes').appendChild(elem);
			setTimeout(function() {
				document.getElementById(node.id).style.opacity = opacity;
			}, 0);
		}
	});
	var existingNodes = [].slice.call(document.getElementsByClassName('node'));
	if (existingNodes.length) {
		existingNodes.forEach(function(node) {
			if (!stateMap[state.id].nodes[node.id]) {
				document.getElementById(node.id).remove();
			}
		});
	}
	if (prevStateIndex > -1) {
		var prevTextElement = document.getElementById(states[prevStateIndex].name);
		if (prevTextElement) {
			prevTextElement.style.top = textTopAfter + 'px';
			prevTextElement.style.opacity = 0;
			setTimeout(function() {
				prevTextElement.style.top = textTopBefore + 'px';
			}, transitionDuration * 1000 + 1000);
		}
	}
	if (!document.getElementById(state.name)) {
		var textElement = document.createElement('div');
		textElement.id = state.name;
		textElement.className = 'text';
		textElement.style.top = textTopBefore + 'px';
		document.getElementById('text').appendChild(textElement);
	}
	setTimeout(function() {
		document.getElementById(state.name).style.top = textTopDuring + 'px';
		document.getElementById(state.name).style.opacity = 1;
	}, 0);
	prevStateIndex = stateIndex;
	stateIndex += 1;
}

function loadJSON(callback) {   
	var xobj = new XMLHttpRequest();
	xobj.overrideMimeType('application/json');
	xobj.open('GET', 'data.json', true);
	xobj.onreadystatechange = function () {
		if (xobj.readyState == 4 && xobj.status == '200') {
			callback(xobj.responseText);
		}
	};
	xobj.send(null);  
}
 
function isIE() {
    return /Trident\/|MSIE/.test(window.navigator.userAgent);
}
 
function load() {
	if (!isIE()) {
		document.getElementById('fallback').remove();
		document.getElementById('edges').setAttribute('width', artboardWidth);
		document.getElementById('edges').setAttribute('height', artboardHeight);		
		if (jsonData) {
			var data = JSON.parse(jsonData);
			states = data.states;
			createStateMap(states);
			addEdgeData(states, stateMap);
			run();
			setInterval(function() {
				run();
			}, slideDuration);			
		} else {
			loadJSON(function(response) {
				var data = JSON.parse(response);
				states = data.states;
				createStateMap(states);
				addEdgeData(states, stateMap);
				run();
				setInterval(function() {
					run();
				}, slideDuration);
			});
		}
	}
}

load();
