var jsonData = '{"width":300,"height":250,"states":[{"id":"s1","name":"organized","text":"","nodes":[{"id":"n1","size":83,"x":57.5,"y":117.5,"type":"jorunn","visibility":"full"},{"id":"n2","size":65,"x":121.5,"y":196.5,"type":"helge","visibility":"full"},{"id":"n3","size":71,"x":239.5,"y":88.5,"type":"lise","visibility":"full"},{"id":"n24","size":18,"x":88,"y":83,"type":"qualityReview","visibility":"hidden"},{"id":"n26","size":22,"x":156,"y":214,"type":"issue","visibility":"hidden"},{"id":"n4","size":36,"x":150,"y":83,"type":"robot","visibility":"full"},{"id":"n5","size":40,"x":154,"y":132,"type":"calendar","visibility":"full"},{"id":"n6","size":33,"x":211.5,"y":164.5,"type":"meeting","visibility":"full"},{"id":"n7","size":23,"x":184.5,"y":60.5,"type":"legal","visibility":"full"},{"id":"n25","size":25,"x":240.5,"y":44.5,"type":"riskAssessment","visibility":"hidden"}],"edges":[{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n2","b":"n6"},{"a":"n3","b":"n5"},{"a":"n3","b":"n6"},{"a":"n4","b":"n5"},{"a":"n4","b":"n7"},{"a":"n1","b":"n24"},{"a":"n2","b":"n26"},{"a":"n3","b":"n25"}]},{"id":"s2","name":"complience","text":"","nodes":[{"id":"n1","size":80,"x":72,"y":116,"type":"jorunn","visibility":"full"},{"id":"n2","size":50,"x":100,"y":210,"type":"helge","visibility":"full"},{"id":"n3","size":47,"x":239.5,"y":162.5,"type":"lise","visibility":"full"},{"id":"n4","size":48,"x":201,"y":99,"type":"robot","visibility":"full"},{"id":"n5","size":52,"x":162,"y":153,"type":"calendar","visibility":"full"},{"id":"n7","size":55,"x":239.5,"y":41.5,"type":"legal","visibility":"full"},{"id":"n8","size":17,"x":254.5,"y":94.5,"type":"corona","visibility":"hidden"},{"id":"n9","size":23,"x":62.5,"y":194.5,"type":"issue","visibility":"hidden"},{"id":"n6","size":16,"x":174,"y":199,"type":"meeting","visibility":"hidden"}],"edges":[{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n2","b":"n6"},{"a":"n3","b":"n5"},{"a":"n3","b":"n6"},{"a":"n4","b":"n5"},{"a":"n4","b":"n7"},{"a":"n4","b":"n8"},{"a":"n2","b":"n9"}]},{"id":"s3","name":"infectioncontrol","text":"","nodes":[{"id":"n1","size":69,"x":73.5,"y":107.5,"type":"jorunn","visibility":"full"},{"id":"n2","size":45,"x":110.5,"y":211.5,"type":"helge","visibility":"full"},{"id":"n3","size":47,"x":245.5,"y":161.5,"type":"lise","visibility":"full"},{"id":"n4","size":57,"x":176.5,"y":97.5,"type":"robot","visibility":"full"},{"id":"n5","size":39,"x":163.5,"y":161.5,"type":"calendar","visibility":"full"},{"id":"n7","size":22,"x":150,"y":83,"type":"legal","visibility":"hidden"},{"id":"n8","size":70,"x":243,"y":46,"type":"corona","visibility":"full"},{"id":"n9","size":40,"x":53,"y":189,"type":"issue","visibility":"full"},{"id":"n10","size":45,"x":132.5,"y":4.5,"type":"personalDataItem","visibility":"hidden"},{"id":"n12","size":25,"x":105.5,"y":41.5,"type":"computer","visibility":"hidden"},{"id":"n13","size":27,"x":129.5,"y":54.5,"type":"computer","visibility":"hidden"},{"id":"n14","size":22,"x":164,"y":37,"type":"computer","visibility":"hidden"},{"id":"n11","size":23,"x":162.5,"y":-17.5,"type":"cloud","visibility":"hidden"}],"edges":[{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n3","b":"n5"},{"a":"n4","b":"n5"},{"a":"n4","b":"n7"},{"a":"n4","b":"n8"},{"a":"n2","b":"n9"},{"a":"n10","b":"n12"},{"a":"n1","b":"n12"},{"a":"n10","b":"n13"},{"a":"n2","b":"n13"},{"a":"n10","b":"n14"},{"a":"n3","b":"n14"},{"a":"n10","b":"n11"}]},{"id":"s4","name":"privacy","text":"","nodes":[{"id":"n1","size":78,"x":49,"y":112,"type":"jorunn","visibility":"full"},{"id":"n2","size":74,"x":107,"y":202,"type":"helge","visibility":"full"},{"id":"n3","size":64,"x":254,"y":167,"type":"lise","visibility":"full"},{"id":"n4","size":25,"x":204.5,"y":191.5,"type":"robot","visibility":"hidden"},{"id":"n5","size":29,"x":187.5,"y":220.5,"type":"calendar","visibility":"hidden"},{"id":"n8","size":17,"x":172.5,"y":175.5,"type":"corona","visibility":"hidden"},{"id":"n9","size":16,"x":48,"y":196,"type":"issue","visibility":"hidden"},{"id":"n10","size":60,"x":172,"y":82,"type":"personalDataItem","visibility":"full"},{"id":"n12","size":29,"x":117.5,"y":99.5,"type":"computer","visibility":"full"},{"id":"n13","size":30,"x":139,"y":148,"type":"computer","visibility":"full"},{"id":"n14","size":31,"x":212.5,"y":124.5,"type":"computer","visibility":"full"},{"id":"n11","size":62,"x":248,"y":45,"type":"cloud","visibility":"full"}],"edges":[{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n3","b":"n5"},{"a":"n4","b":"n5"},{"a":"n4","b":"n8"},{"a":"n2","b":"n9"},{"a":"n10","b":"n11"},{"a":"n1","b":"n12"},{"a":"n10","b":"n12"},{"a":"n2","b":"n13"},{"a":"n10","b":"n13"},{"a":"n10","b":"n14"},{"a":"n3","b":"n14"}]},{"id":"s5","name":"calendar","text":"","nodes":[{"id":"n1","size":70,"x":52,"y":108,"type":"jorunn","visibility":"full"},{"id":"n2","size":63,"x":102.5,"y":204.5,"type":"helge","visibility":"full"},{"id":"n3","size":61,"x":247.5,"y":82.5,"type":"lise","visibility":"full"},{"id":"n15","size":21,"x":70.5,"y":78.5,"type":"function","visibility":"hidden"},{"id":"n16","size":16,"x":263,"y":69,"type":"function","visibility":"hidden"},{"id":"n17","size":18,"x":128,"y":183,"type":"function","visibility":"hidden"},{"id":"n5","size":80,"x":154,"y":125,"type":"calendar","visibility":"full"},{"id":"n10","size":18,"x":146,"y":20,"type":"personalDataItem","visibility":"hidden"},{"id":"n12","size":19,"x":122.5,"y":35.5,"type":"computer","visibility":"hidden"},{"id":"n13","size":20,"x":136,"y":46,"type":"computer","visibility":"hidden"},{"id":"n14","size":21,"x":165.5,"y":41.5,"type":"computer","visibility":"hidden"},{"id":"n11","size":22,"x":172,"y":-3,"type":"cloud","visibility":"hidden"}],"edges":[{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n3","b":"n5"},{"a":"n10","b":"n11"},{"a":"n1","b":"n12"},{"a":"n10","b":"n12"},{"a":"n2","b":"n13"},{"a":"n10","b":"n13"},{"a":"n10","b":"n14"},{"a":"n3","b":"n14"},{"a":"n1","b":"n15"},{"a":"n3","b":"n16"},{"a":"n2","b":"n17"}]},{"id":"s6","name":"responsibility","text":"","nodes":[{"id":"n1","size":70,"x":70,"y":123,"type":"jorunn","visibility":"full"},{"id":"n2","size":58,"x":102,"y":201,"type":"helge","visibility":"full"},{"id":"n3","size":70,"x":196,"y":108,"type":"lise","visibility":"full"},{"id":"n15","size":40,"x":120,"y":77,"type":"function","visibility":"full"},{"id":"n16","size":40,"x":247,"y":62,"type":"function","visibility":"full"},{"id":"n17","size":31,"x":141.5,"y":155.5,"type":"function","visibility":"full"},{"id":"n18","size":47,"x":311.5,"y":135.5,"type":"bemanning","visibility":"hidden"},{"id":"n5","size":21,"x":137.5,"y":122.5,"type":"calendar","visibility":"hidden"}],"edges":[{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n3","b":"n5"},{"a":"n1","b":"n15"},{"a":"n3","b":"n16"},{"a":"n2","b":"n17"},{"a":"n1","b":"n18"},{"a":"n3","b":"n18"},{"a":"n2","b":"n18"}]},{"id":"s7","name":"staffing","text":"","nodes":[{"id":"n1","size":46,"x":45,"y":77,"type":"jorunn","visibility":"full"},{"id":"n2","size":46,"x":47,"y":194,"type":"helge","visibility":"full"},{"id":"n3","size":46,"x":254,"y":77,"type":"lise","visibility":"full"},{"id":"n18","size":141,"x":148.5,"y":125.5,"type":"bemanning","visibility":"full"},{"id":"n20","size":30,"x":-67,"y":118,"type":"asset","visibility":"hidden"},{"id":"n19","size":30,"x":-66,"y":159,"type":"asset","visibility":"hidden"},{"id":"n23","size":20,"x":-29,"y":118,"type":"task","visibility":"hidden"},{"id":"n22","size":20,"x":-30,"y":159,"type":"task","visibility":"hidden"},{"id":"n15","size":19,"x":49.5,"y":113.5,"type":"function","visibility":"hidden"},{"id":"n16","size":19,"x":272.5,"y":40.5,"type":"function","visibility":"hidden"},{"id":"n17","size":19,"x":90.5,"y":198.5,"type":"function","visibility":"hidden"}],"edges":[{"a":"n1","b":"n15"},{"a":"n3","b":"n16"},{"a":"n2","b":"n17"},{"a":"n1","b":"n18"},{"a":"n3","b":"n18"},{"a":"n2","b":"n18"},{"a":"n1","b":"n20"},{"a":"n19","b":"n20"},{"a":"n20","b":"n23"},{"a":"n2","b":"n23"},{"a":"n19","b":"n22"},{"a":"n2","b":"n22"}]},{"id":"s8","name":"assets","text":"","nodes":[{"id":"n1","size":67,"x":51.5,"y":115.5,"type":"jorunn","visibility":"full"},{"id":"n2","size":63,"x":249.5,"y":141.5,"type":"helge","visibility":"full"},{"id":"n3","size":25,"x":366.5,"y":79.5,"type":"lise","visibility":"hidden"},{"id":"n20","size":50,"x":127,"y":114,"type":"asset","visibility":"full"},{"id":"n19","size":50,"x":127,"y":176,"type":"asset","visibility":"full"},{"id":"n23","size":30,"x":182,"y":114,"type":"task","visibility":"full"},{"id":"n22","size":30,"x":182,"y":175,"type":"task","visibility":"full"},{"id":"n21","size":31,"x":257.5,"y":30.5,"type":"meeting","visibility":"hidden"},{"id":"n18","size":33,"x":346.5,"y":115.5,"type":"bemanning","visibility":"hidden"}],"edges":[{"a":"n1","b":"n18"},{"a":"n3","b":"n18"},{"a":"n2","b":"n18"},{"a":"n19","b":"n20"},{"a":"n19","b":"n22"},{"a":"n20","b":"n23"},{"a":"n1","b":"n20"},{"a":"n2","b":"n23"},{"a":"n2","b":"n22"},{"a":"n1","b":"n21"},{"a":"n3","b":"n21"},{"a":"n2","b":"n21"}]},{"id":"s9","name":"meetings","text":"","nodes":[{"id":"n1","size":58,"x":54,"y":113,"type":"jorunn","visibility":"full"},{"id":"n2","size":56,"x":93,"y":201,"type":"helge","visibility":"full"},{"id":"n3","size":57,"x":246.5,"y":116.5,"type":"lise","visibility":"full"},{"id":"n20","size":26,"x":124,"y":268,"type":"asset","visibility":"hidden"},{"id":"n19","size":26,"x":125,"y":300,"type":"asset","visibility":"hidden"},{"id":"n23","size":19,"x":149.5,"y":266.5,"type":"task","visibility":"hidden"},{"id":"n22","size":18,"x":150,"y":301,"type":"task","visibility":"hidden"},{"id":"n21","size":80,"x":151,"y":125,"type":"meeting","visibility":"full"},{"id":"n24","size":19,"x":85.5,"y":79.5,"type":"qualityReview","visibility":"hidden"},{"id":"n25","size":24,"x":236,"y":73,"type":"riskAssessment","visibility":"hidden"},{"id":"n26","size":19,"x":129.5,"y":185.5,"type":"issue","visibility":"hidden"}],"edges":[{"a":"n19","b":"n20"},{"a":"n19","b":"n22"},{"a":"n20","b":"n23"},{"a":"n1","b":"n20"},{"a":"n2","b":"n23"},{"a":"n2","b":"n22"},{"a":"n1","b":"n21"},{"a":"n3","b":"n21"},{"a":"n2","b":"n21"},{"a":"n1","b":"n24"},{"a":"n3","b":"n25"},{"a":"n2","b":"n26"}]},{"id":"s10","name":"improvement","text":"","nodes":[{"id":"n1","size":41,"x":48.5,"y":107.5,"type":"jorunn","visibility":"full"},{"id":"n2","size":40,"x":107,"y":204,"type":"helge","visibility":"full"},{"id":"n3","size":42,"x":238,"y":136,"type":"lise","visibility":"full"},{"id":"n24","size":61,"x":111.5,"y":121.5,"type":"qualityReview","visibility":"full"},{"id":"n26","size":53,"x":159.5,"y":168.5,"type":"issue","visibility":"full"},{"id":"n25","size":58,"x":180,"y":107,"type":"riskAssessment","visibility":"full"},{"id":"n5","size":40,"x":145,"y":64,"type":"calendar","visibility":"hidden"},{"id":"n6","size":20,"x":207,"y":208,"type":"meeting","visibility":"hidden"},{"id":"n4","size":26,"x":181,"y":37,"type":"robot","visibility":"hidden"},{"id":"n21","size":23,"x":175.5,"y":190.5,"type":"meeting","visibility":"hidden"},{"id":"n7","size":15,"x":206.5,"y":54.5,"type":"legal","visibility":"hidden"}],"edges":[{"a":"n1","b":"n21"},{"a":"n3","b":"n21"},{"a":"n2","b":"n21"},{"a":"n1","b":"n24"},{"a":"n3","b":"n25"},{"a":"n2","b":"n26"},{"a":"n1","b":"n5"},{"a":"n2","b":"n5"},{"a":"n3","b":"n5"},{"a":"n3","b":"n6"},{"a":"n2","b":"n6"},{"a":"n4","b":"n5"},{"a":"n4","b":"n7"}]}]}';
var states = [];
var stateMap = {};
var stateIndex = 0;
var prevStateIndex = -1;
var artboardWidth = 300;
var artboardHeight = 250;
var textTopBefore = 300;
var textTopDuring = 16;
var textTopAfter = -60;
var edgeWidth = 2;
var slideDuration = 3000;
var transitionDuration = .5;
var keySplines = '.42 0 .58 1';

function getEdgeCoordinates(ax, ay, ar, bx, by, br) {
	var w = bx - ax;
	var h = by - ay;
	var length = Math.sqrt(Math.pow(w, 2) + Math.pow(h, 2));
	var aFactor = ar / length;
	var bFactor = br / length;
	ax = ax + w * aFactor;
	bx = bx - w * bFactor;
	ay = ay + h * aFactor;
	by = by - h * bFactor;
	return {ax: ax, ay: ay, bx: bx, by: by}
}

function createStateMap(states) {
	states.forEach(function(state) {
		stateMap[state.id] = {
			nodes:{}, 
			edges:{}
		};
		state.nodes.forEach(function(node) {
			stateMap[state.id].nodes[node.id] = node;
		});
		state.edges.forEach(function(edge) {
			edge.id = edge.a + edge.b;
			var nodeA = stateMap[state.id].nodes[edge.a];
			var nodeB = stateMap[state.id].nodes[edge.b];
			if (nodeA && nodeB) {
				var edgeCoordinates = getEdgeCoordinates(nodeA.x, nodeA.y, nodeA.size / 2, nodeB.x, nodeB.y, nodeB.size / 2);
				edge.ax = edgeCoordinates.ax;
				edge.ay = edgeCoordinates.ay;
				edge.bx = edgeCoordinates.bx;
				edge.by = edgeCoordinates.by;
				edge.opacity = 1;
				if (nodeA.visibility === 'damped' || nodeB.visibility === 'damped') {
					edge.opacity = 0.3;
				}
				if (nodeA.visibility === 'hidden' || nodeB.visibility === 'hidden') {
					edge.opacity = 0;
				}
				stateMap[state.id].edges[edge.id] = edge;
			}
		});
	});
}

function addEdgeData(states, stateMap) {
	states.forEach(function(state) {
		state.edges.forEach(function(edge) {
			edge = stateMap[state.id].edges[edge.a + edge.b];
		});
	});
}

function insertEdge(edge) {
	var line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
	line.setAttribute('id', edge.id);
	line.setAttribute('x1', edge.ax);
	line.setAttribute('y1', edge.ay);
	line.setAttribute('x2', edge.bx);
	line.setAttribute('y2', edge.by);
	line.setAttribute('y2', edge.by);
	line.setAttribute('stroke', 'white')
	line.setAttribute('stroke-width', edgeWidth);
	line.setAttribute('stroke-opacity', 0);
	document.getElementById('edges').appendChild(line);
}

function animateEdgeProperty(edgeId, attributeName, from, to) {
	if(!document.getElementById('animate-' + stateIndex + '-' + edgeId + '-' + attributeName)) {
		var animate = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
		animate.setAttribute('id', 'animate-' + stateIndex + '-' + edgeId + '-' + attributeName);
		animate.setAttribute('attributeName', attributeName);
		animate.setAttribute('from', from);
		animate.setAttribute('to', to);
		animate.setAttribute('dur', transitionDuration + 's');
		animate.setAttribute('calcMode', 'spline');
		animate.setAttribute('keyTimes', '0; 1');
		animate.setAttribute('keySplines', keySplines);
		animate.setAttribute('fill', 'freeze');
		document.getElementById(edgeId).appendChild(animate);
	}
	document.getElementById('animate-' + stateIndex + '-' + edgeId + '-' + attributeName).beginElement();
	setTimeout(function() {
		var edge = document.getElementById(edgeId);
	}, transitionDuration * 1000);
}

function removeEdge(edgeId) {
	var animate = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
	animate.setAttribute('id', 'animate-' + edgeId);
	animate.setAttribute('attributeName', 'stroke-opacity');
	animate.setAttribute('to', 0);
	animate.setAttribute('dur', transitionDuration + 's');
	animate.setAttribute('calcMode', 'spline');
	animate.setAttribute('keyTimes', '0; 1');
	animate.setAttribute('keySplines', keySplines);
	animate.setAttribute('fill', 'freeze');
	document.getElementById(edgeId).appendChild(animate);
	document.getElementById('animate-' + edgeId).beginElement();
	setTimeout(function() {
		if (document.getElementById(edgeId)) {
			document.getElementById(edgeId).remove();
		}
	}, transitionDuration * 1000 + 100);
}

function run() {
	if (stateIndex > states.length - 1) {
		stateIndex = 0;
	}
	var state = states[stateIndex];
	var svg = document.getElementById('edges');
	var existingEdges = svg.querySelectorAll('line');
	var existingEdgeIds = [];
	existingEdges.forEach(function(edge) {
		existingEdgeIds.push(edge.id);
		if (stateMap[state.id].edges[edge.id]) {
			var prevStateEdge = stateMap[states[prevStateIndex].id].edges[edge.id];
			if (prevStateEdge) {
				var currentStateEdge = stateMap[states[stateIndex].id].edges[edge.id];
				animateEdgeProperty(edge.id, 'x1', prevStateEdge.ax, currentStateEdge.ax);
				animateEdgeProperty(edge.id, 'x2', prevStateEdge.bx, currentStateEdge.bx);
				animateEdgeProperty(edge.id, 'y1', prevStateEdge.ay, currentStateEdge.ay);
				animateEdgeProperty(edge.id, 'y2', prevStateEdge.by, currentStateEdge.by);
				animateEdgeProperty(edge.id, 'stroke-opacity', prevStateEdge.opacity, currentStateEdge.opacity);
			} else {
				removeEdge(edge.id);
			}
		} else {
			removeEdge(edge.id);
		}
	});
	state.edges.forEach(function(edge) {
		if (existingEdgeIds.indexOf(edge.id) < 0) {
			insertEdge(edge);
			animateEdgeProperty(edge.id, 'stroke-opacity', 0, edge.opacity);
		}
	});
	state.nodes.forEach(function(node) {
		var opacity = 0;
		if (node.visibility === 'full') {
			opacity = 1;
		}
		var elem = document.getElementById(node.id);
		var shadowDist = (node.size / 60) * (node.size / 60);
		var shadowBlur = (node.size / 40) * (node.size / 80) + 4;
		var shadowSpread = node.size / 100;
		if (elem) {
			elem.style.left = node.x - node.size / 2 + 'px';
			elem.style.top = node.y - node.size / 2 + 'px';
			elem.style.width = node.size + 'px';
			elem.style.height = node.size + 'px';
			elem.style.opacity = opacity;
			elem.style.boxShadow = 'rgba(0, 0, 0, 0.3) ' + shadowDist + 'px ' + shadowDist + 'px ' + shadowBlur + 'px ' + shadowSpread + 'px';
		} else {
			elem = document.createElement('div');
			elem.id = node.id;
			elem.className = 'node ' + node.type;
			elem.style.left = node.x - node.size / 2 + 'px';
			elem.style.top = node.y - node.size / 2 + 'px';
			elem.style.width = node.size + 'px';
			elem.style.height = node.size + 'px';
			elem.style.opacity = 0;
			elem.style.boxShadow = 'rgba(0, 0, 0, 0.3) ' + shadowDist + 'px ' + shadowDist + 'px ' + shadowBlur + 'px ' + shadowSpread + 'px';
			document.getElementById('nodes').appendChild(elem);
			setTimeout(function() {
				document.getElementById(node.id).style.opacity = opacity;
			}, 0);
		}
	});
	var existingNodes = [].slice.call(document.getElementsByClassName('node'));
	if (existingNodes.length) {
		existingNodes.forEach(function(node) {
			if (!stateMap[state.id].nodes[node.id]) {
				document.getElementById(node.id).remove();
			}
		});
	}
	if (prevStateIndex > -1) {
		var prevTextElement = document.getElementById(states[prevStateIndex].name);
		if (prevTextElement) {
			prevTextElement.style.top = textTopAfter + 'px';
			prevTextElement.style.opacity = 0;
			setTimeout(function() {
				prevTextElement.style.top = textTopBefore + 'px';
			}, transitionDuration * 1000 + 1000);
		}
	}
	if (!document.getElementById(state.name)) {
		var textElement = document.createElement('div');
		textElement.id = state.name;
		textElement.className = 'text';
		textElement.style.top = textTopBefore + 'px';
		document.getElementById('text').appendChild(textElement);
	}
	setTimeout(function() {
		document.getElementById(state.name).style.top = textTopDuring + 'px';
		document.getElementById(state.name).style.opacity = 1;
	}, 0);
	prevStateIndex = stateIndex;
	stateIndex += 1;
}

function loadJSON(callback) {   
	var xobj = new XMLHttpRequest();
	xobj.overrideMimeType('application/json');
	xobj.open('GET', 'data.json', true);
	xobj.onreadystatechange = function () {
		if (xobj.readyState == 4 && xobj.status == '200') {
			callback(xobj.responseText);
		}
	};
	xobj.send(null);  
}

function isIE() {
    return /Trident\/|MSIE/.test(window.navigator.userAgent);
}
 
function load() {
	if (!isIE()) {
		document.getElementById('fallback').remove();
		document.getElementById('edges').setAttribute('width', artboardWidth);
		document.getElementById('edges').setAttribute('height', artboardHeight);		
		if (jsonData) {
			var data = JSON.parse(jsonData);
			states = data.states;
			createStateMap(states);
			addEdgeData(states, stateMap);
			run();
			setInterval(function() {
				run();
			}, slideDuration);			
		} else {
			loadJSON(function(response) {
				var data = JSON.parse(response);
				states = data.states;
				createStateMap(states);
				addEdgeData(states, stateMap);
				run();
				setInterval(function() {
					run();
				}, slideDuration);
			});
		}
	}
}

load();
